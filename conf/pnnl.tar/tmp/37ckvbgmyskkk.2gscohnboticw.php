<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>FlashVpn Panels</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/metisMenu/2.0.0/metisMenu.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
    <link href="/asset/css/sb-admin-2.css" rel="stylesheet">
    <link href="/asset/css/bootstrap-datepicker3.min.css" rel="stylesheet">
    <link href="/asset/css/bootstrap-dialog.min.css" rel="stylesheet">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>
<body>
    <?php echo $this->render($content,$this->mime,get_defined_vars()); ?>
    <script src="https://code.jquery.com/jquery-2.1.3.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/metisMenu/2.0.0/metisMenu.min.js"></script>
    <script src="/asset/js/sb-admin-2.js"></script>
    <script src="/asset/js/bootstrap-datepicker.min.js"></script>
    <script src="/asset/js/bootstrap-dialog.min.js"></script>
    <script type="text/javascript">
        $('.input-group.date').datepicker({
            format: "yyyy/mm/dd",
            weekStart: 1,
            clearBtn: true,
            language: "id",
            autoclose: true,
            todayHighlight: true
        });
        $('.hapus').click(function(e) {
            e.preventDefault();
            BootstrapDialog.confirm({
                title: 'Confirm',
                message: ' Yakin Gan ?',
                type: BootstrapDialog.TYPE_DANGER,
                closable: true,
                btnCancelLabel: 'Batal',
                btnOKLabel: 'Delete',
                btnOKClass: 'btn-danger',
                callback: function(result) {
                    if(result) {
                        location.href = $('.hapus').attr('href');
                    }
                }
            });
        });
        function print_report() {
            window.print();
            return false;
        }
    </script>
</body>
</html>
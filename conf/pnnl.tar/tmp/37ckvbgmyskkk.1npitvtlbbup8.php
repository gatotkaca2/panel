<div id="wrapper">
    <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="/home"><i class="fa fa-dashboard fa-lg fa-fw"></i> Joeker Flashvpn Panel</a>
        </div>
        <div class="navbar-default sidebar" role="navigation">
            <div class="sidebar-nav navbar-collapse">
                <ul class="nav" id="side-menu">
                    <li class="sidebar-search">
                        <div class="row">
                            <div class="col-xs-5">
                                <span class="fa-stack fa-3x">
                                    <img class="img-responsive"  src="http://img02.deviantart.net/fa80/i/2013/087/c/3/joker_icon_by_slamiticon-d5z2zhc.png" alt="joeker" width="55" height="10">
                                    <i class="fa fa-user fa-stack-1x fa-inverse"></i>
                                </span>
                            </div>
                            <div class="col-xs-7">
                                <h4><b><?php echo $me->username; ?></b></h4>
                                <h4 class="text-muted"><?php echo $me->type==1?'Admin':'Seller'; ?></h4>
                            </div>
                        </div>
                    </li>
                    <?php if ($me->type==1): ?>
                        
                            <li>
                                <a href="/home/admin/server"><i class="fa fa-th-list fa-fw"></i> Server</a>
                            </li>
                            <li>
                                <a href="/home/admin/seller"><i class="fa fa-group fa-fw"></i> Seller</a>
                            </li>
                        
                        <?php else: ?>
                            <li>
                                <a href="/home/member/server"><i class="fa fa-shopping-cart fa-fw"></i> Beli SSH Account</a>
                            </li>
                        
                    <?php endif; ?>
                    <li>
                        <a href="/home/setting"><i class="fa fa-gear fa-fw"></i> Setting</a>
                    </li>
                    <li>
                        <a href="/logout"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <?php echo $this->render($subcontent,$this->mime,get_defined_vars()); ?>
</div>
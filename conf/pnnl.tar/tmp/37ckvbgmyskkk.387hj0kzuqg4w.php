<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">SSH User List
                <small><?php echo $server->servername; ?></small>
                <a href="<?php echo $URI; ?>/add" class="btn btn-default pull-right"><i class="fa fa-plus fa-fw"></i> Tambah</a>
            </h1>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <i class="fa fa-group fa-fw"></i> Account List
                </div>
                <div class="panel-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Username</th>
                                    <th>Create By</th>
                                    <th>Exp</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if ($users): ?>
                                    
                                        <?php $no=0; foreach (($users?:array()) as $user): $no++; ?>
                                            <tr>
                                                <td><?php echo $no; ?></td>
                                                <td><?php echo $user->user; ?></td>
                                                <td><?php echo $user->real; ?></td>
                                                <td><?php echo $user->exp; ?></td>
                                                <td>
                                                    <a href="<?php echo $URI.'/'.$user->uid; ?>" class="btn btn-primary">Edit</a>
                                                    <?php if ($user->lock): ?>
                                                        
                                                            <a href="<?php echo $URI.'/'.$user->uid; ?>/active/1" class="btn btn-success">Unlock</a>
                                                        
                                                        <?php else: ?>
                                                            <a href="<?php echo $URI.'/'.$user->uid; ?>/active/0" class="btn btn-warning">Lock</a>
                                                        
                                                    <?php endif; ?>
                                                    <a href="<?php echo $URI.'/'.$user->uid; ?>/delete" class="btn btn-danger hapus">Hapus</a>
                                                </td>
                                             </tr>
                                        <?php endforeach; ?>
                                    
                                    <?php else: ?>
                                        <tr>
                                            <td class="text-muted text-center" colspan="6"> No User</td>
                                        </tr>
                                    
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>